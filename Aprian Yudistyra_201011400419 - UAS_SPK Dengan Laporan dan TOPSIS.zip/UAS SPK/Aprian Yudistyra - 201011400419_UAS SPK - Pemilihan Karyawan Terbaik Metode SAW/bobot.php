<html>
  <?php
require "desain/head.php";
require "koneksi.php";
?>
    <head>
<style>
        body {
            margin: 0;
            font-family: Nunito;
            font-size: 1rem;
            font-weight: 400;
            line-height: 1.5;
            color: #607080;
            background-color:lightgray;
            -webkit-text-size-adjust: 100%;
            -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
        }
    </style>
</head>
  <body>
    <div id="app">
      <?php require "desain/sidebar.php";?>
      <div id="main">
        <header class="mb-3">
          <a href="#" class="burger-btn d-block d-xl-none">
            <i class="bi bi-justify fs-3"></i>
          </a>
        </header>
        <div class="page-heading">
          <h3>Bobot Kriteria</h3>
        </div>
        <div class="page-content">
          <section class="row">
            <div class="col-12">
              <div class="card">

                <div class="card-header">
                  <h4 class="card-title">Tabel Bobot Kriteria</h4>
                    <p class="card-text">Terdapat 2 jenis Kriteria yaitu, benefit atau cost</p>
                    <p class="card-text">
                              Rentang nilai nya 1-6. Keterangan :
                          </p>
                  <div class="row">
                      <div class="col-md-6">
                          <ul>A. C1 &amp; C4 adalah Cost (Biaya)
                              <li>1 = Sangat Murah Sekali</li>
                              <li>2 = Sangat Murah</li>
                              <li>3 = Biasa</li>
                              <li>4 = Lumayan</li>
                              <li>5 = Lumayan Mahal</li>
                              <li>6 = Mahal Sekali</li>
                          </ul>
                      </div>
                      <div class="col-md-6">
                          <ul>B. C2 &amp; C3 &amp; C5 adalah Benefit (Keuntungan)
                              <li>1 = Sangat Rendah Sekali</li>
                              <li>2 = Sangat Rendah</li>
                              <li>3 = Biasa</li>
                              <li>4 = Bagus</li>
                              <li>5 = Bagus sekali</li>
                              <li>6 = Sangat Bagus Sekali</li>
                          </ul>
                      </div>
                  </div>
              </div>

                  <caption>
    Tabel Kriteria C<sub>i</sub>
  </caption>
                  <div class="table-responsive">
                    <table class="table table-striped mb-0">
  <tr>
    <th>No</th>
    <th>Simbol</th>
    <th>Kriteria</th>
    <th>Bobot</th>
    <th colspan="2">Atribut</th>
  </tr>
  <?php
$sql = 'SELECT id_kriteria,kriteria,bobotk,atribut FROM saw_kriteria';
$result = $db->query($sql);
$i = 0;
while ($row = $result->fetch_object()) {
    echo "<tr>
        <td class='right'>" . (++$i) . "</td>
        <td class='center'>C{$i}</td>
        <td>{$row->kriteria}</td>
        <td>{$row->bobotk}</td>
        <td>{$row->atribut}</td>
        <td>
            <a href='bobote.php?id={$row->id_kriteria}' class='btn btn-info btn-sm'>Edit</a>
            </td>
      </tr>\n";
}
$result->free();
?>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
        <?php require "desain/footer.php";?>
      </div>
    </div>
    <?php require "desain/js.php";?>
  </body>

</html>