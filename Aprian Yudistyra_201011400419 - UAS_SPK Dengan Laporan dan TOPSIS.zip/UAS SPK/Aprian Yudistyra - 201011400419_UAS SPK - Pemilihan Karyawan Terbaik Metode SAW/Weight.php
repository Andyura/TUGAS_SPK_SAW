<?php
$sql = "SELECT bobotk FROM saw_kriteria ORDER BY id_kriteria";
$result = $db->query($sql);
$i = 0;
$W = array();
while ($row = $result->fetch_object()) {
    $W[] = $row->bobotk;
}
