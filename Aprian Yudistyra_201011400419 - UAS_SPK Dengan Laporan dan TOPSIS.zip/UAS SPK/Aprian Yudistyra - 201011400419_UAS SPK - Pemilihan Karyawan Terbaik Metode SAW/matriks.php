<?php
require "koneksi.php";

$id_alt = $_POST['id_alt'];
$id_kriteria = $_POST['id_kriteria'];
$value = $_POST['value'];

$sql = "INSERT INTO saw_htng values ('$id_alt','$id_kriteria','$value')";
$result = $db->query($sql);

if ($result === true) {
    header("location:./matrik.php");
} else {
    echo "Error: " . $sql . "<br>" . $db->error;
}
