<?php
require "koneksi.php";
$id = $_POST['id_alt'];
$name = $_POST['nama'];
$sql = "UPDATE saw_alt SET name='$name' WHERE id_alt='$id'";
$result = $db->query($sql);
header("location:./alternatif.php");
