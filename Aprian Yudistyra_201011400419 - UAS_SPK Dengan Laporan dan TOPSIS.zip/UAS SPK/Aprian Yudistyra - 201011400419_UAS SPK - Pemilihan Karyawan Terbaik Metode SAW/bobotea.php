<?php
require "koneksi.php";
$id = $_POST['id_kriteria'];
$kriteria = $_POST['kriteria'];
$bobotk = $_POST['bobotk'];
$atribut = $_POST['atribut'];

$sql = "UPDATE saw_kriteria SET kriteria='$kriteria',bobotk='$bobotk',atribut='$atribut' WHERE id_kriteria='$id'";
$result = $db->query($sql);
header("location:./bobot.php");
