<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p>Desember 2023 &copy; SPK - Metode SAW</p>
        </div>
        <div class="float-end">
            <p> <a
                    href="https://www.aprian.yudistyra@gmail.com">Aprian Yudistyra - 201011400419</a></p>
        </div>
    </div>
</footer>
