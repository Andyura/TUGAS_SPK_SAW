<html>
    <?php require "desain/head.php";?>
    <head>
<style>
        body {
            margin: 0;
            font-family: Nunito;
            font-size: 1rem;
            font-weight: 400;
            line-height: 1.5;
            color: #607080;
            background-color:lightgray;
            -webkit-text-size-adjust: 100%;
            -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
        }
    </style>
</head>
    <body>
        <div id="app">
            <?php require "desain/sidebar.php";?>
            <div id="main">
                <header class="mb-3">
                    <a href="#" class="burger-btn d-block d-xl-none">
                        <i class="bi bi-justify fs-3"></i>
                    </a>
                </header>
              
                <div class="page-heading">
                    <h3>Dashboard</h3>
                </div>
                <div class="page-content">
                    <section class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4>Tugas Mata Kuliah Sistem Penunjang Keputusan.
                                        <br>
                                        SPK Pemilihan Karyawan Terbaik.
                                    </h4>
                                </div>
                                <div class="card-content">
                                    <div class="card-body">
                                        <p class="card-text">
                                            Menggunkan Metode Simple Additive Weighting (SAW).
                                        </p>
                                        <hr>
                                        <p class="card-text">
                                           Ada yang perlu diperhatikan dalam metode SAW ini, yaitu :
                                        </p>
                                        <ol type="1">
                                            <li>Adanya kriteria untuk  pengambilan keputusan terhadap karyawan yang dipilih</i>
                                            <li> Adanya Bobot pada tiap kriteria.
                                            </li>
                                            <li>Menilai karyawaan tiap sesuai kriteria.</li>
                                            <li>Hasil akhir didapat dari perankingan dimana nilai terbesar adalah Karyawan Terbaik!</li>
                                        </ol>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>



                <?php require "desain/footer.php";?>
            </div>
        </div>
        <?php require "desain/js.php";?>
    </body>

</html>