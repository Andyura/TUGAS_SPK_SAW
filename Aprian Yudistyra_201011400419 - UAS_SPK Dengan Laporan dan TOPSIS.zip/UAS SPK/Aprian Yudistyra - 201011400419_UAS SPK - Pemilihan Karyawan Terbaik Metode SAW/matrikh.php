<?php
require "koneksi.php";
$id = $_GET['id'];
mysqli_query($db, "delete from saw_htng where id_alt='$id'");

header("location:./matrik.php");
