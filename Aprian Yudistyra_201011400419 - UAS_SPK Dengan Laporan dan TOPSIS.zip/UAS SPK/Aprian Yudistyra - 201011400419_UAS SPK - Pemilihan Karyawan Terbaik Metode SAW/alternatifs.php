<?php
require "koneksi.php";
$nama = $_POST['nama'];

$sql = "INSERT INTO saw_alt (nama) VALUES ('$nama')";

if ($db->query($sql) === true) {
    header("location:./alternatif.php");
} else {
    echo "Error: " . $sql . "<br>" . $db->error;
}

