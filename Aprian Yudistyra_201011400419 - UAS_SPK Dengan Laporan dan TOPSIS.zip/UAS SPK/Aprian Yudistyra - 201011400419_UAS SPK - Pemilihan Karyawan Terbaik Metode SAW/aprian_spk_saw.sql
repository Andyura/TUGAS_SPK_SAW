-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 22, 2023 at 01:15 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aprian_spk_saw`
--

-- --------------------------------------------------------

--
-- Table structure for table `saw_alt`
--

CREATE TABLE `saw_alt` (
  `id_alt` smallint(5) UNSIGNED NOT NULL,
  `nama` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `saw_alt`
--

INSERT INTO `saw_alt` (`id_alt`, `nama`) VALUES
(9, 'Amin'),
(8, 'Nurul'),
(7, 'Mari'),
(6, 'Siti'),
(5, 'Lapu'),
(4, 'Aprian'),
(3, 'Sinegar'),
(2, 'Fullo'),
(1, 'Cakra'),
(10, 'Polo'),
(24, 'Uca');

-- --------------------------------------------------------

--
-- Table structure for table `saw_htng`
--

CREATE TABLE `saw_htng` (
  `id_alt` smallint(5) UNSIGNED NOT NULL,
  `id_kriteria` tinyint(3) UNSIGNED NOT NULL,
  `value` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `saw_htng`
--

INSERT INTO `saw_htng` (`id_alt`, `id_kriteria`, `value`) VALUES
(1, 5, 4),
(1, 4, 3),
(1, 3, 1),
(1, 2, 2),
(1, 1, 2),
(4, 5, 4),
(4, 4, 2),
(4, 3, 3),
(4, 2, 3),
(4, 1, 1),
(3, 5, 1),
(3, 4, 3),
(3, 3, 2),
(3, 2, 4),
(3, 1, 2),
(2, 5, 2),
(2, 4, 1),
(2, 3, 5),
(2, 2, 4),
(2, 1, 3),
(5, 5, 2),
(5, 4, 3),
(5, 3, 1),
(5, 2, 6),
(5, 1, 4),
(6, 3, 1),
(6, 5, 3),
(6, 4, 6),
(6, 2, 4),
(6, 1, 5),
(7, 4, 4),
(7, 3, 2),
(7, 1, 1),
(7, 2, 2),
(7, 5, 5),
(8, 1, 4),
(8, 2, 2),
(8, 3, 3),
(8, 4, 1),
(8, 5, 6),
(9, 1, 3),
(9, 2, 3),
(9, 3, 2),
(9, 4, 1),
(9, 5, 4),
(10, 1, 4),
(10, 2, 2),
(10, 3, 1),
(10, 4, 6),
(10, 5, 2);

-- --------------------------------------------------------

--
-- Table structure for table `saw_kriteria`
--

CREATE TABLE `saw_kriteria` (
  `id_kriteria` tinyint(3) UNSIGNED NOT NULL,
  `kriteria` varchar(100) NOT NULL,
  `bobotk` float NOT NULL,
  `atribut` set('benefit','cost') DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `saw_kriteria`
--

INSERT INTO `saw_kriteria` (`id_kriteria`, `kriteria`, `bobotk`, `atribut`) VALUES
(1, 'Biaya Pengembangan', 0.2, 'cost'),
(2, 'Kinerja', 0.3, 'benefit'),
(3, 'Kemampuan Adaptasi', 0.2, 'benefit'),
(4, 'Biaya Pelatihan', 0.1, 'cost'),
(5, 'Kemampuan Leadership', 0.2, 'benefit');

-- --------------------------------------------------------

--
-- Table structure for table `saw_users`
--

CREATE TABLE `saw_users` (
  `id_user` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `saw_users`
--

INSERT INTO `saw_users` (`id_user`, `username`, `password`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `saw_alt`
--
ALTER TABLE `saw_alt`
  ADD PRIMARY KEY (`id_alt`);

--
-- Indexes for table `saw_htng`
--
ALTER TABLE `saw_htng`
  ADD PRIMARY KEY (`id_alt`,`id_kriteria`);

--
-- Indexes for table `saw_kriteria`
--
ALTER TABLE `saw_kriteria`
  ADD PRIMARY KEY (`id_kriteria`);

--
-- Indexes for table `saw_users`
--
ALTER TABLE `saw_users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `saw_alt`
--
ALTER TABLE `saw_alt`
  MODIFY `id_alt` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `saw_users`
--
ALTER TABLE `saw_users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
