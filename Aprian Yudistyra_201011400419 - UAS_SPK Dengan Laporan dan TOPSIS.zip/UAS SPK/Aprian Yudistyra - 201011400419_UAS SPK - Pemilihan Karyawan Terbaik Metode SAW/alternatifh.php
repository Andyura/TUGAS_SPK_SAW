<?php
require "koneksi.php";
$id = $_GET['id'];
mysqli_query($db, "delete from saw_alt where id_alt='$id'");
header("location:./alternatif.php");
